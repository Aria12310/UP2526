/*
Copyright (c) 2024 Limelight Vision

All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted (subject to the limitations in the disclaimer below) provided that
the following conditions are met:

Redistributions of source code must retain the above copyright notice, this list
of conditions and the following disclaimer.

Redistributions in binary form must reproduce the above copyright notice, this
list of conditions and the following disclaimer in the documentation and/or
other materials provided with the distribution.

Neither the name of FIRST nor the names of its contributors may be used to
endorse or promote products derived from this software without specific prior
written permission.

NO EXPRESS OR IMPLIED LICENSES TO ANY PARTY'S PATENT RIGHTS ARE GRANTED BY THIS
LICENSE. THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
"AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE
FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR
TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF
THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/
package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.limelightvision.LLResult;
import com.qualcomm.hardware.limelightvision.LLResultTypes;
import com.qualcomm.hardware.limelightvision.LLStatus;
import com.qualcomm.hardware.limelightvision.Limelight3A;
import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.DigitalChannel;
import com.qualcomm.robotcore.hardware.Servo;
import com.qualcomm.robotcore.hardware.IMU;
import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import com.qualcomm.robotcore.util.ElapsedTime;

import org.firstinspires.ftc.robotcore.external.navigation.AngleUnit;
import org.firstinspires.ftc.robotcore.external.navigation.Pose3D;

import java.util.List;

/*
 * This OpMode illustrates how to use the Limelight3A Vision Sensor.
 *
 * @see <a href="https://limelightvision.io/">Limelight</a>
 *
 * Notes on configuration:
 *
 *   The device presents itself, when plugged into a USB port on a Control Hub as an ethernet
 *   interface.  A DHCP server running on the Limelight automatically assigns the Control Hub an
 *   ip address for the new ethernet interface.
 *
 *   Since the Limelight is plugged into a USB port, it will be listed on the top level configuration
 *   activity along with the Control Hub Portal and other USB devices such as webcams.  Typically
 *   serial numbers are displayed below the device's names.  In the case of the Limelight device, the
 *   Control Hub's assigned ip address for that ethernet interface is used as the "serial number".
 *
 *   Tapping the Limelight's name, transitions to a new screen where the user can rename the Limelight
 *   and specify the Limelight's ip address.  Users should take care not to confuse the ip address of
 *   the Limelight itself, which can be configured through the Limelight settings page via a web browser,
 *   and the ip address the Limelight device assigned the Control Hub and which is displayed in small text
 *   below the name of the Limelight on the top level configuration screen.
 */
@TeleOp(name = "Sensor: Limelight3A", group = "Sensor")
//@Disabled
public class Limelight2 extends LinearOpMode {

    private Limelight3A limelight;
    private ElapsedTime runtime = new ElapsedTime();
    private DcMotor frontLeftDrive = null;
    private DcMotor backLeftDrive = null;
    private DcMotor frontRightDrive = null;
    private DcMotor backRightDrive = null;
    //    private DcMotorEx highMotor;//higher placed motor for the launcher
//    private DcMotorEx lowMotor;//lower placed motor for the launcher
    private Servo cupRaise = null; //servo that moves the rack and pin of the cup
    private DcMotor intake = null;//intake motor



    // External encoder connected via REV Through-Bore adapter cable
    private DcMotorEx highFlyWheel;
    private DcMotorEx lowFlyWheel;
    private IMU imu = null;

    // Encoder constants
    private static final double COUNTS_PER_REV = 8192.0;  // Confirm from REV datasheet

    // PIDF coefficients
    private double kP = 0.01;
    private double kI = 0.000;
    private double kD = 0.001;
    private double kF = 0.0;

    // PID state
    private double integralSum = 0;
    private double lastError = 0;
    private long lastTime = 0;


    @Override
    public void runOpMode() throws InterruptedException {
        imu = hardwareMap.get(IMU.class, "imu");
        limelight = hardwareMap.get(Limelight3A.class, "limelight");
        frontLeftDrive = hardwareMap.get(DcMotor.class, "left_front_drive");
        backLeftDrive = hardwareMap.get(DcMotor.class, "left_back_drive");
        frontRightDrive = hardwareMap.get(DcMotor.class, "right_front_drive");
        backRightDrive = hardwareMap.get(DcMotor.class, "right_back_drive");
//        highMotor = hardwareMap.get(DcMotorEx.class, "high_motor");
//        lowMotor= hardwareMap.get(DcMotorEx.class, "low_motor");
        highFlyWheel = hardwareMap.get(DcMotorEx.class, "encoder");// map the REV Through-Bore via config
        lowFlyWheel = hardwareMap.get(DcMotorEx.class, "low_encoder");
        cupRaise = hardwareMap.get(Servo.class, "cupRaiseServo");
        intake = hardwareMap.get(DcMotor.class, "intake");


        highFlyWheel.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        highFlyWheel.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        lowFlyWheel.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        lowFlyWheel.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        // Motor should run without its internal encoder
//        highMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);
//        lowMotor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        telemetry.addLine("Ready - press Play");
        telemetry.setMsTransmissionInterval(11);
        telemetry.update();
        limelight.pipelineSwitch(0);


        frontLeftDrive.setDirection(DcMotor.Direction.REVERSE);
        backLeftDrive.setDirection(DcMotor.Direction.REVERSE);
        frontRightDrive.setDirection(DcMotor.Direction.FORWARD);
        backRightDrive.setDirection(DcMotor.Direction.FORWARD);

        highFlyWheel.setDirection(DcMotor.Direction.REVERSE);
        lowFlyWheel.setDirection(DcMotor.Direction.REVERSE);

//        highFlyWheel.setDirection(DcMotorEx.Direction.REVERSE);

//        highMotor.setDirection(DcMotor.Direction.REVERSE);
        intake.setDirection(DcMotor.Direction.FORWARD);
        /*
         * Starts polling for data.  If you neglect to call start(), getLatestResult() will return null.
         */
        limelight.start();

        telemetry.addData(">", "Robot Ready.  Press Play.");
        telemetry.update();
        waitForStart();
        // Set a target velocity (in RPM) change to alter speed
        double targetRMP = -3345;

        lastTime = System.nanoTime();

        double cupDown = 0;//cup position
        cupRaise.setPosition(cupDown);

        while (opModeIsActive()) {




//            if (gamepad2.a) {
//                highFlyWheel.setPower(.75);
//                lowFlyWheel.setPower(.75);
//
//            }
//            if (gamepad2.b) {
//                highFlyWheel.setPower(0);
//                lowFlyWheel.setPower(0);

//            } else {
//                highFlyWheel.setPower(0);
//                lowFlyWheel.setPower(0);
//            }

            // Calculate velocity from encoder
            double currentVelocityRPM = getEncoderVelocityRPM();
//
//            // Calculate velocity from encoder
//            double lowEncoderCurrentVelocityRPM = getLowEncoderVelocityRPM();
//
            // Compute error
            double error = targetRMP - currentVelocityRPM;

            double targetVelocity = 2 * 3.14 * 0.0476 * targetRMP;
//            double lowEncoderError = targetRPM - lowEncoderCurrentVelocityRPM;
//
            if (gamepad2.a && (error != 0)) {
                highFlyWheel.setPower(-.55);
                lowFlyWheel.setPower(-.55);
            }
            if (gamepad2.b) {
                highFlyWheel.setPower(0);
                lowFlyWheel.setPower(0);
        }
            telemetry.addData("velocity",currentVelocityRPM);
            telemetry.addData("error", error);
////
////            if (lowEncoderError!=0){
////                lowMotorEncoder.setVelocity(getLowEncoderVelocityRPM());
////            }

            double max;

            // POV Mode uses left joystick to go forward & strafe, and right joystick to rotate.
            double axial = -gamepad1.left_stick_y;  // Note: pushing stick forward gives negative value
            double lateral = gamepad1.left_stick_x;
            double yaw = gamepad1.right_stick_x;

            // Combine the joystick requests for each axis-motion to determine each wheel's power.
            // Set up a variable for each drive wheel to save the power level for telemetry.
            double frontLeftPower = axial + lateral + yaw;
            double frontRightPower = axial - lateral - yaw;
            double backLeftPower = axial - lateral + yaw;
            double backRightPower = axial + lateral - yaw;

            // Normalize the values so no wheel power exceeds 100%
            // This ensures that the robot maintains the desired motion.
            max = Math.max(Math.abs(frontLeftPower), Math.abs(frontRightPower));
            max = Math.max(max, Math.abs(backLeftPower));
            max = Math.max(max, Math.abs(backRightPower));

            if (max > 1.0) {
                frontLeftPower /= max;
                frontRightPower /= max;
                backLeftPower /= max;
                backRightPower /= max;
            }
            frontLeftDrive.setPower(frontLeftPower);
            frontRightDrive.setPower(frontRightPower);
            backLeftDrive.setPower(backLeftPower);
            backRightDrive.setPower(backRightPower);


            // cup servo code
            double cupUp = .48;
            if (gamepad2.y) {//raise cup
                cupRaise.setPosition(cupUp);
                runtime.reset();
                sleep(3000);
                cupRaise.setPosition(cupDown);
            }
            if (gamepad2.x) {//lower cup
                cupRaise.setPosition(cupDown);
            }

// inake on left trigger
            if (gamepad2.left_trigger > 0.95) {
                intake.setPower(-.95);
            } else {
                intake.setPower(0);
            }
//'outtake' on right
            if (gamepad2.right_trigger > 0.95) {
                intake.setPower(.95);
            } else {
                intake.setPower(0);
            }


            LLStatus status = limelight.getStatus();


            telemetry.addData("Name", "%s",
                    status.getName());
//            telemetry.addData("LL", "Temp: %.1fC, CPU: %.1f%%, FPS: %d",
//                    status.getTemp(), status.getCpu(), (int) status.getFps());
//            telemetry.addData("Pipeline", "Index: %d, Type: %s",
//                    status.getPipelineIndex(), status.getPipelineType());

            LLResult result = limelight.getLatestResult();
            if (result.isValid()) {
                // Access general information
                Pose3D botpose = result.getBotpose();
//                double captureLatency = result.getCaptureLatency();
//                double targetingLatency = result.getTargetingLatency();
//                double parseLatency = result.getParseLatency();
//                telemetry.addData("LL Latency", captureLatency + targetingLatency);
//                telemetry.addData("Parse Latency", parseLatency);
//                telemetry.addData("PythonOutput", java.util.Arrays.toString(result.getPythonOutput()));

//                telemetry.addData("tx", result.getTx());
//                telemetry.addData("txnc", result.getTxNC());.
//                telemetry.addData("ty", result.getTy());
//                telemetry.addData("tync", result.getTyNC());

                telemetry.addData("Botpose", botpose.toString());

                // Access barcode results
//                List<LLResultTypes.BarcodeResult> barcodeResults = result.getBarcodeResults();
//                for (LLResultTypes.BarcodeResult br : barcodeResults) {
//                    telemetry.addData("Barcode", "Data: %s", br.getData());
//                }
//
//                // Access classifier results
//                List<LLResultTypes.ClassifierResult> classifierResults = result.getClassifierResults();
//                for (LLResultTypes.ClassifierResult cr : classifierResults) {
//                    telemetry.addData("Classifier", "Class: %s, Confidence: %.2f", cr.getClassName(), cr.getConfidence());
//                }
//
//                // Access detector results
//                List<LLResultTypes.DetectorResult> detectorResults = result.getDetectorResults();
//                for (LLResultTypes.DetectorResult dr : detectorResults) {
//                    telemetry.addData("Detector", "Class: %s, Area: %.2f", dr.getClassName(), dr.getTargetArea());
//                }
//
//                // Access fiducial results
//                List<LLResultTypes.FiducialResult> fiducialResults = result.getFiducialResults();
//                for (LLResultTypes.FiducialResult fr : fiducialResults) {
//                    telemetry.addData("Fiducial", "ID: %d, Family: %s, X: %.2f, Y: %.2f", fr.getFiducialId(), fr.getFamily(), fr.getTargetXDegrees(), fr.getTargetYDegrees());
//                }
//
//                // Access color results
//                List<LLResultTypes.ColorResult> colorResults = result.getColorResults();
//                for (LLResultTypes.ColorResult cr : colorResults) {
//                    telemetry.addData("Color", "X: %.2f, Y: %.2f", cr.getTargetXDegrees(), cr.getTargetYDegrees());
//                }
            } else {
                telemetry.addData("Limelight", "No data available");

                telemetry.addData("lower Flywheel encoder count: ", lowFlyWheel.getCurrentPosition());
                telemetry.addData("cup servo postion", cupRaise.getPosition());

                telemetry.update();
            }
            if (result != null && result.isValid()) {
                Pose3D botpose = result.getBotpose();
                if (botpose != null) {
                    double x = botpose.getPosition().x;
                    double y = botpose.getPosition().y;
                    telemetry.addData("MT1 Location", "(" + x + ", " + y + ")");


                }
            }
            double robotYaw = imu.getRobotYawPitchRollAngles().getYaw(AngleUnit.DEGREES);
            limelight.updateRobotOrientation(robotYaw);
            if (result != null && result.isValid()) {
                Pose3D botpose_mt2 = result.getBotpose_MT2();
                if (botpose_mt2 != null) {
                    double xMt2 = botpose_mt2.getPosition().x;
                    double yMt2 = botpose_mt2.getPosition().y;
                    telemetry.addData("MT2 Location:", "(" + xMt2 + ", " + yMt2 + ")");
                }
            }
        }
    }



//        limelight.stop();

    public double getEncoderVelocityRPM() {
        int currentPosition = highFlyWheel.getCurrentPosition();
        long currentTime = System.nanoTime();

        sleep(20);  // short delay for measurement window

        int newPosition = highFlyWheel.getCurrentPosition();
        long newTime = System.nanoTime();

        int deltaTicks = newPosition - currentPosition;
        double deltaTime = (newTime - currentTime) / 1e9; // seconds

        double ticksPerSecond = deltaTicks / deltaTime;
        double revolutionsPerSecond = ticksPerSecond / COUNTS_PER_REV;

        return revolutionsPerSecond * 60.0; // RPM
    }

// public double getLowEncoderVelocityRPM() {
//    int currentPosition = lowMotorEncoder.getCurrentPosition();
//    long currentTime = System.nanoTime();
//
//    sleep(20);  // short delay for measurement window
//
//    int newPosition = lowMotorEncoder.getCurrentPosition();
//    long newTime = System.nanoTime();
//
//    int deltaTicks = newPosition - currentPosition;
//    double deltaTime = (newTime - currentTime) / 1e9; // seconds
//
//    double ticksPerSecond = deltaTicks / deltaTime;
//    double revolutionsPerSecond = ticksPerSecond / COUNTS_PER_REV;
//
//    return revolutionsPerSecond * 60.0; // RPM
//}
//
//    private double clamp(double val, double min, double max) {
//        return Math.max(min, Math.min(max, val));
//    }
}