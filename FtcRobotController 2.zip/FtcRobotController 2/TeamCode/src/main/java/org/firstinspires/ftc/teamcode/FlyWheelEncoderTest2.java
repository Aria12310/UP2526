package org.firstinspires.ftc.teamcode;

import com.qualcomm.robotcore.eventloop.opmode.Disabled;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotorEx;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.HardwareMap;
import com.qualcomm.robotcore.hardware.DigitalChannel;
@Disabled
@com.qualcomm.robotcore.eventloop.opmode.TeleOp(name = "Velocity Control with Through-Bore Encoder")
public class FlyWheelEncoderTest2 extends LinearOpMode {
    // Your motor connected to the hub
    private DcMotorEx motor;

    // External encoder connected via REV Through-Bore adapter cable
    private DcMotorEx encoder;

    // Encoder constants
    private static final double COUNTS_PER_REV = 8192.0;  // Confirm from REV datasheet

    // PIDF coefficients
    private double kP = 0.01;
    private double kI = 0.000;
    private double kD = 0.001;
    private double kF = 0.0;

    // PID state
    private double integralSum = 0;
    private double lastError = 0;
    private long lastTime = 0;

    @Override
    public void runOpMode() {
        motor = hardwareMap.get(DcMotorEx.class, "motor");
        encoder = hardwareMap.get(DcMotorEx.class, "encoder"); // map the REV Through-Bore via config

        // Reset encoder
        encoder.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);
        encoder.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        // Motor should run without its internal encoder
        motor.setMode(DcMotor.RunMode.RUN_WITHOUT_ENCODER);

        telemetry.addLine("Ready - press Play");
        telemetry.update();
        waitForStart();

        // Set a target velocity (in RPM)
        double targetRPM = 120.0;

        lastTime = System.nanoTime();

        while (opModeIsActive()) {
            // Calculate velocity from encoder
            double currentVelocityRPM = getEncoderVelocityRPM();

            // Compute error
            double error = targetRPM - currentVelocityRPM;

            // PID control
            long now = System.nanoTime();
            double deltaTime = (now - lastTime) / 1e9; // seconds
            lastTime = now;

            integralSum += error * deltaTime;
            double derivative = (error - lastError) / deltaTime;

            double output = kP * error + kI * integralSum + kD * derivative + kF * targetRPM;
            output = clamp(output, -1.0, 1.0);

            // Apply power
            motor.setPower(output);

            lastError = error;

            // Telemetry
            telemetry.addData("Target RPM", targetRPM);
            telemetry.addData("Current RPM", "%.2f", currentVelocityRPM);
            telemetry.addData("Error", "%.2f", error);
            telemetry.addData("Output Power", "%.2f", output);
            telemetry.update();
        }
    }

    // Returns velocity in RPM
    private double getEncoderVelocityRPM() {
        int currentPosition = encoder.getCurrentPosition();
        long currentTime = System.nanoTime();

        sleep(20);  // short delay for measurement window

        int newPosition = encoder.getCurrentPosition();
        long newTime = System.nanoTime();

        int deltaTicks = newPosition - currentPosition;
        double deltaTime = (newTime - currentTime) / 1e9; // seconds

        double ticksPerSecond = deltaTicks / deltaTime;
        double revolutionsPerSecond = ticksPerSecond / COUNTS_PER_REV;

        return revolutionsPerSecond * 60.0; // RPM
    }

    private double clamp(double val, double min, double max) {
        return Math.max(min, Math.min(max, val));
    }
}