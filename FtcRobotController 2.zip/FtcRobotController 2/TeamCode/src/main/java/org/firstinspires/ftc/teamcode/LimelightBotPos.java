//// ExampleOpMode_NoIMU.java
//package org.firstinspires.ftc.teamcode;
//
//import com.qualcomm.robotcore.eventloop.opmode.Disabled;
//import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
//import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
//import com.qualcomm.robotcore.hardware.HardwareMap;
//
//import com.qualcomm.hardware.limelightvision.Limelight3A;
//import com.qualcomm.hardware.limelightvision.LLResult;
//import com.qualcomm.hardware.limelightvision.LLResultTypes;
//import com.qualcomm.hardware.limelightvision.LLStatus;
//@Disabled
//@Autonomous(name="Drive-to-Point (Limelight-Only)", group="Auto")
//public class ExampleOpMode_NoIMU extends LinearOpMode {
//
//    private Limelight3A limelight;
//    private DriveTrain drive;
//
//    // Target position on the field (in meters)
//    private static final double TARGET_X = 2.0;
//    private static final double TARGET_Y = 1.0;
//
//    @Override
//    public void runOpMode() throws InterruptedException {
//        // Initialize Limelight and drivetrain
//        limelight = hardwareMap.get(Limelight3A.class, "limelight");
//        drive = new DriveTrain(hardwareMap);
//
//        limelight.pipelineSwitch(0);  // your AprilTag pipeline
//        limelight.start();
//
//        telemetry.addLine("Limelight Initialized. Waiting for start...");
//        telemetry.update();
//
//        waitForStart();
//
//        while (opModeIsActive()) {
//            LLResult result = limelight.getLatestResult();
//
//            if (result != null && result.isValid()) {
//                // Pose3D gives full 3D pose relative to the field
//                botpose.toString = result.getBotpose_MT2();  // meters, degrees
//                double botX = botPose.getX();
//                double botY = botPose.getY();
//                double botYaw = botPose.getYaw();  // <-- Heading from AprilTag
//
//                // Calculate vector to the target
//                double deltaX = TARGET_X - botX;
//                double deltaY = TARGET_Y - botY;
//                double distance = Math.hypot(deltaX, deltaY);
//                double angleToTarget = Math.toDegrees(Math.atan2(deltaY, deltaX));
//
//                // Heading correction
//                double headingError = normalizeAngle(angleToTarget - botYaw);
//
//                // Simple proportional control
//                double turnPower = headingError * 0.01;  // tune gain
//                double drivePower = distance * 0.2;      // tune gain
//
//                turnPower = clamp(turnPower, -0.3, 0.3);
//                drivePower = clamp(drivePower, 0, 0.5);
//
//                // Drive behavior
//                if (Math.abs(headingError) < 10.0) {
//                    drive.arcadeDrive(drivePower, turnPower);
//                } else {
//                    drive.arcadeDrive(0, turnPower);
//                }
//
//                telemetry.addData("Pose X (m)", botX);
//                telemetry.addData("Pose Y (m)", botY);
//                telemetry.addData("Yaw (deg)", botYaw);
//                telemetry.addData("Dist to Target", distance);
//                telemetry.addData("Heading Error", headingError);
//
//                // Stop when close to target
//                if (distance < 0.1) {
//                    drive.arcadeDrive(0, 0);
//                    telemetry.addData("Status", "Reached Target");
//                    telemetry.update();
//                    break;
//                }
//            } else {
//                telemetry.addData("Limelight", "No valid pose");
//                drive.arcadeDrive(0, 0);
//            }
//
//            telemetry.update();
//            sleep(20);
//        }
//
//        drive.stop();
//    }
//
//    private double normalizeAngle(double angle) {
//        while (angle > 180) angle -= 360;
//        while (angle < -180) angle += 360;
//        return angle;
//    }
//
//    private double clamp(double v, double min, double max) {
//        return Math.max(min, Math.min(max, v));
//    }
//
//    // Example drivetrain template — replace with your robot's implementation
//    static class DriveTrain {
//        public DriveTrain(HardwareMap hw) {
//            // Initialize motors, encoders, etc.
//        }
//
//        public void arcadeDrive(double forward, double turn) {
//            // Implement your arcade drive logic here
//        }
//
//        public void stop() {
//            arcadeDrive(0, 0);
//        }
//    }
//}
